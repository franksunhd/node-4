var app = require('express')();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
server.listen(3000, function(){
    console.log('Wetsite: http://localhost:3000');
});

app.get('/', function(req, res, next){
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){
//io.on('connection', function(socket){
  socket.emit('news', {hello: 'world'});
  socket.on('other', function(data){
    console.log(data);
  });
});
