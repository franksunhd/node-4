var mongoose = require('mongoose');
mongoose.connect('mongodb://cnstu.top/stu');

var db = mongoose.connection;


var tasksSchema = mongoose.Schema({
  taskname: String,
  public: Boolean,
  finshed: Boolean,
  data: Date,
});

module.exports.students = mongoose.model('Task', tasksSchema);



//Task.find({}, {sort: { _id: -1}})


module.exports.db = db;
