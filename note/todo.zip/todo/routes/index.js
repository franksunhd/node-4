var express = require('express');
var router = express.Router();
var task = require('../colletions/index');


var user = [];
user.push({name: 'Richard', age:2, sex: 'M'});
user.push({name: 'Richard', age:2, sex: 'M'});
user.push({name: 'Richard', age:2, sex: 'M'});
/* GET home page. */
router.get('/', function(req, res) {

  task.students.find({}, ['taskname', 'data'], {sort: {data: -1}}, function(err, resulte){
    if(err)  console.log(err);
    console.log(resulte);

    res.render('index', {title: 'Todo List', task: resulte});
  });

});

router.post('/submit', function(req, res) {
  var stu = new task.students({
    taskname: req.body.todo,
    public: true,
    finshed: false,
    data: Date.now()
  });
  stu.save(function(err, data){
    if(err) console.log(err);
  });
  task.students.find({}, ['taskname', 'data'], {sort: {data: -1}}, function(err, data){
    data.unshift(stu);
  res.render('submit', {title: 'Todo List', task: data});
  });
});

module.exports = router;
